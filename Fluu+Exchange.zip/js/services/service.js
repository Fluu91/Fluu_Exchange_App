/*
 * Service settings
 */
var Twilio_settings = {
    "accountSid": "{accountSidProxy}",
    "version": "2010-04-01",
    "phoneNumber": ""
}
var Fluu_Exchange_settings = {
    "database_url": "https://api.appery.io/rest/1/db",
    "database_id": "570fe580e4b06624d2ed325d"
}
var Twilio_settings_Twilio_Message_API = {
    "accountSid": "{accountSidProxy}",
    "version": "2010-04-01",
    "phoneNumber": ""
}

/*
 * Services
 */

var Twilio_showMessages_Twilio_Message_API = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'https://api.twilio.com/{version}/Accounts/{accountSid}/SMS/Messages.json',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460719179405',
        'appery-rest': 'a7ee84a4-e833-4abe-b4ad-cc8175d4c932'
    },
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': Twilio_settings_Twilio_Message_API

    ,
    'defaultRequest': {
        "headers": {
            "Authorization": "{authString}"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange__files_upload_service = new Apperyio.RestService({
    'url': '{database_url}/files',
    'dataType': 'json',
    'type': 'post',
    'contentType': false,

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange__files_read_service = new Apperyio.RestService({
    'url': '{database_url}/files/{database_id}/{file_name}',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange__files_delete_service = new Apperyio.RestService({
    'url': '{database_url}/files/{file_name}',
    'dataType': 'json',
    'type': 'delete',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange_Contacts_delete_service = new Apperyio.RestService({
    'url': '{database_url}/collections/Contacts/{_id}',
    'dataType': 'json',
    'type': 'delete',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange_Contacts_list_service = new Apperyio.RestService({
    'url': '{database_url}/collections/Contacts',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange_Contacts_query_service = new Apperyio.RestService({
    'url': '{database_url}/collections/Contacts',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange__files_create_service = new Apperyio.RestService({
    'url': '{database_url}/files/{file_name}',
    'dataType': 'json',
    'type': 'post',
    'contentType': false,

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}",
            "Content-Type": "application/octet-stream"
        },
        "parameters": {},
        "body": null
    }
});
var locationService = new Apperyio.GeolocationService({
    'echo': {
        "coords": {
            "latitude": "37.97194",
            "longitude": "-122.042688",
            "altitude": null,
            "accuracy": "50",
            "altitudeAccuracy": null,
            "heading": null,
            "speed": null
        },
        "timestamp": "2011-10-12T12:04:52.290Z"
    },
    'defaultRequest': {
        "data": {
            "options": {
                "maximumAge": 3000,
                "timeout": 5000,
                "enableHighAccuracy": true,
                "watchPosition": false
            }
        }
    }
});

var Twilio_sendMessage_Twilio_Message_API = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'https://api.twilio.com/{version}/Accounts/{accountSid}/Messages.json',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460719179406',
        'appery-rest': 'a7ee84a4-e833-4abe-b4ad-cc8175d4c932'
    },
    'dataType': 'json',
    'type': 'post',
    'contentType': 'application/x-www-form-urlencoded',

    'serviceSettings': Twilio_settings_Twilio_Message_API

    ,
    'defaultRequest': {
        "headers": {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": "{authString}"
        },
        "parameters": {},
        "body": {
            "From": "{phoneNumber}"
        }
    }
});

var Fluu_Exchange_Contacts_update_service = new Apperyio.RestService({
    'url': '{database_url}/collections/Contacts/{_id}',
    'dataType': 'json',
    'type': 'put',
    'contentType': 'application/json',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}",
            "Content-Type": "application/json"
        },
        "parameters": {},
        "body": {
            "acl": {
                "*": {
                    "write": true,
                    "read": true
                }
            }
        }
    }
});

var Fluu_Exchange_Contacts_read_service = new Apperyio.RestService({
    'url': '{database_url}/collections/Contacts/{_id}',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange_signup_service = new Apperyio.RestService({
    'url': '{database_url}/users',
    'dataType': 'json',
    'type': 'post',
    'contentType': 'application/json',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}",
            "Content-Type": "application/json"
        },
        "parameters": {},
        "body": null
    }
});

var Fluu_Exchange_Contacts_create_service = new Apperyio.RestService({
    'url': '{database_url}/collections/Contacts',
    'dataType': 'json',
    'type': 'post',
    'contentType': 'application/json',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}",
            "Content-Type": "application/json"
        },
        "parameters": {},
        "body": {
            "acl": {
                "*": {
                    "write": true,
                    "read": true
                }
            }
        }
    }
});

var Fluu_Exchange_login_service = new Apperyio.RestService({
    'url': '{database_url}/login',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Twilio_sendMessage = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'https://api.twilio.com/{version}/Accounts/{accountSid}/Messages.json',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460719179406',
        'appery-rest': 'a7ee84a4-e833-4abe-b4ad-cc8175d4c932'
    },
    'dataType': 'json',
    'type': 'post',
    'contentType': 'application/x-www-form-urlencoded',

    'serviceSettings': Twilio_settings

    ,
    'defaultRequest': {
        "headers": {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": "{authString}"
        },
        "parameters": {},
        "body": {
            "From": "{phoneNumber}"
        }
    }
});

var Fluu_Exchange_logout_service = new Apperyio.RestService({
    'url': '{database_url}/logout',
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': Fluu_Exchange_settings

    ,
    'defaultRequest': {
        "headers": {
            "X-Appery-Database-Id": "{database_id}"
        },
        "parameters": {},
        "body": null
    }
});

var Twilio_showMessages = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'https://api.twilio.com/{version}/Accounts/{accountSid}/SMS/Messages.json',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460719179407',
        'appery-rest': 'a7ee84a4-e833-4abe-b4ad-cc8175d4c932'
    },
    'dataType': 'json',
    'type': 'get',

    'serviceSettings': Twilio_settings

    ,
    'defaultRequest': {
        "headers": {
            "Authorization": "{authString}"
        },
        "parameters": {},
        "body": null
    }
});